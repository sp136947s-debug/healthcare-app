# NIDAN Go-Live Plan

## Landing
`landing/` is a polished static site. GitHub Pages can publish it through the included workflow.

## API
Deploy `backend/Dockerfile` to a container host with PostgreSQL + pgvector. Set:
OPENAI_API_KEY, OPENAI_MODEL, OPENAI_EMBEDDING_MODEL, DATABASE_URL, CORS_ORIGINS, GOOGLE_PLACES_API_KEY (optional).

Use HTTPS in production.

## Mobile
After the API is live, set `mobile/lib/config.dart` to the HTTPS API URL, then:
`flutter pub get`
`flutter build apk --release`

## Production checklist
Use rate limiting, monitoring, privacy/consent controls, secure authentication where needed, HTTPS, restricted API keys, and legal/privacy review before real patient data.
