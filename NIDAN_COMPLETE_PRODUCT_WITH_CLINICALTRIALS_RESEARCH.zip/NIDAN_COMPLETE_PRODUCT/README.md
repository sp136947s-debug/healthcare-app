# NIDAN — Full VS Code Ready MVP

NIDAN is a voice-first, multilingual healthcare navigation assistant:
**Bolna → samajhna → safe guidance → next step → healthcare access.**

## Stack
- Flutter / Dart mobile app
- Python / FastAPI backend
- PostgreSQL + pgvector
- OpenAI Responses API for the AI assistant
- OpenAI embeddings for RAG
- Device speech-to-text + TTS for the MVP
- Google Places API (New) optional for nearby healthcare

## Safety boundary
NIDAN is a healthcare navigation and information assistant, not a doctor and not a diagnostic system.
It must escalate emergency symptoms and must not invent medical records, ABHA status, facilities, prices, appointments, or treatment instructions.

## Quick start
See `SETUP.md`.

### ClinicalTrials.gov research layer

NIDAN now includes a live **ClinicalTrials.gov registry discovery layer**:
- `GET /clinical-trials/search?term=...&location=India`
- `GET /clinical-trials/{NCT_ID}`
- local cache table: `clinical_trials`
- research presets: `backend/data/clinical_trials_research_presets.json`
- batch sync script: `backend/scripts/sync_clinical_trials.py`

This layer is for registered-study discovery and research context. It must not be used to diagnose users, recommend treatment, or infer individual trial eligibility.
