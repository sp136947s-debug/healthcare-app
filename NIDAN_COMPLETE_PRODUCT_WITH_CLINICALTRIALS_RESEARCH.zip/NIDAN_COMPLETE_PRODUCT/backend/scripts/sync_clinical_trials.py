"""
Sync selected ClinicalTrials.gov research domains into local JSONL.

Run from backend:
    python scripts/sync_clinical_trials.py

This is a research-data cache, not a clinical decision-support database.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import httpx

BASE = "https://clinicaltrials.gov/api/v2"
OUT = Path(__file__).resolve().parents[1] / "data" / "clinical_trials_cache.jsonl"

TERMS = [
    "digital health India",
    "telemedicine India",
    "mobile health India",
    "rural health India",
    "healthcare access India",
    "patient education India",
    "diabetes India",
    "hypertension India",
    "tuberculosis India",
    "maternal health India",
    "child health India",
    "mental health India",
    "vaccination India",
]

async def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    async with httpx.AsyncClient(timeout=30) as client, OUT.open("w", encoding="utf-8") as f:
        for term in TERMS:
            r = await client.get(
                f"{BASE}/studies",
                params={"query.term": term, "pageSize": 100, "format": "json"},
            )
            r.raise_for_status()
            payload = r.json()
            for study in payload.get("studies", []):
                f.write(json.dumps(study, ensure_ascii=False) + "\n")
            print(term, "=>", len(payload.get("studies", [])))

if __name__ == "__main__":
    asyncio.run(main())
