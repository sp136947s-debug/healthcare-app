from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .db import ClinicalTrial


CTG_URL = settings.clinicaltrials_api_base.rstrip("/")


def _join(values: list[Any] | None) -> str:
    if not values:
        return ""
    out = []
    for v in values:
        if isinstance(v, dict):
            out.append(v.get("name") or v.get("text") or json.dumps(v, ensure_ascii=False))
        else:
            out.append(str(v))
    return "; ".join([x for x in out if x])


def normalize_study(study: dict[str, Any]) -> dict[str, Any]:
    p = study.get("protocolSection", {})
    ident = p.get("identificationModule", {})
    status_m = p.get("statusModule", {})
    design_m = p.get("designModule", {})
    desc_m = p.get("descriptionModule", {})
    cond_m = p.get("conditionsModule", {})
    interv_m = p.get("armsInterventionsModule", {})
    sponsor_m = p.get("sponsorCollaboratorsModule", {})
    loc_m = p.get("contactsLocationsModule", {})

    nct = ident.get("nctId", "")
    locations = []
    for loc in (loc_m.get("locations") or [])[:100]:
        parts = [loc.get("facility"), loc.get("city"), loc.get("state"), loc.get("country")]
        locations.append(", ".join([x for x in parts if x]))

    return {
        "nct_id": nct,
        "title": ident.get("briefTitle") or ident.get("officialTitle") or "",
        "status": status_m.get("overallStatus") or "",
        "phase": _join(design_m.get("phases")),
        "study_type": design_m.get("studyType") or "",
        "conditions": _join(cond_m.get("conditions")),
        "interventions": _join([
            x.get("name") or x.get("type") or ""
            for x in (interv_m.get("interventions") or [])
        ]),
        "sponsor": (sponsor_m.get("leadSponsor") or {}).get("name", ""),
        "locations": "; ".join(locations),
        "summary": desc_m.get("briefSummary") or "",
        "source_url": f"https://clinicaltrials.gov/study/{nct}" if nct else "https://clinicaltrials.gov/",
        "last_updated": status_m.get("lastUpdatePostDateStruct", {}).get("date"),
        "raw_json": study,
    }


async def search_trials(
    term: str,
    location: str | None = None,
    page_size: int = 20,
) -> dict[str, Any]:
    """Search ClinicalTrials.gov live. This is registry discovery, not treatment advice."""
    q = term.strip()
    if location:
        q = f"{q} AND AREA[LocationCountry]{location}"
    params = {
        "query.term": q,
        "pageSize": min(max(page_size, 1), 100),
        "format": "json",
    }
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(f"{CTG_URL}/studies", params=params)
        r.raise_for_status()
        return r.json()


async def get_trial(nct_id: str) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(f"{CTG_URL}/studies/{nct_id}")
        r.raise_for_status()
        return r.json()


def cache_study(db: Session, study: dict[str, Any]) -> dict[str, Any]:
    item = normalize_study(study)
    if not item["nct_id"]:
        raise ValueError("ClinicalTrials.gov study has no NCT ID")

    row = db.scalar(select(ClinicalTrial).where(ClinicalTrial.nct_id == item["nct_id"]))
    updated = None
    if item["last_updated"]:
        try:
            updated = datetime.fromisoformat(item["last_updated"]).replace(tzinfo=timezone.utc)
        except ValueError:
            updated = None

    if row is None:
        row = ClinicalTrial(
            nct_id=item["nct_id"],
            title=item["title"],
            status=item["status"],
            phase=item["phase"],
            study_type=item["study_type"],
            conditions=item["conditions"],
            interventions=item["interventions"],
            sponsor=item["sponsor"],
            locations=item["locations"],
            summary=item["summary"],
            source_url=item["source_url"],
            last_updated=updated,
            raw_json=json.dumps(item["raw_json"], ensure_ascii=False),
        )
        db.add(row)
    else:
        for k in [
            "title", "status", "phase", "study_type", "conditions",
            "interventions", "sponsor", "locations", "summary", "source_url"
        ]:
            setattr(row, k, item[k])
        row.last_updated = updated
        row.raw_json = json.dumps(item["raw_json"], ensure_ascii=False)

    db.commit()
    return item
