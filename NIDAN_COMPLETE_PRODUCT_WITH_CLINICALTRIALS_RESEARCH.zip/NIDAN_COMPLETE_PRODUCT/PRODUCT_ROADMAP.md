# NIDAN Product Roadmap

Included: multilingual voice assistant, OpenAI Responses API, PostgreSQL + pgvector RAG, emergency escalation, live healthcare search integration, ABHA help boundary, report text help, anonymous sessions, feedback, Flutter app, landing page, GitHub Pages workflow.

Next: official ABDM/ABHA authenticated flows, approved healthcare directory, consent-based document/image understanding, authentication, privacy/audit controls, rate limiting, analytics, offline mode, human escalation, app-store release.
